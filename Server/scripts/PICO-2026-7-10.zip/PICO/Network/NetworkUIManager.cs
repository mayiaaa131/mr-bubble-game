using UnityEngine;
using TMPro;
using BubbleBattle.Network;
using BubbleBattle;

public class NetworkUIManager : MonoBehaviour
{
    [SerializeField] private Canvas connectedCanvas;
    [SerializeField] private Canvas disconnectedCanvas;
    [SerializeField] private TMP_Text roomNumberText; // B Canvas ����ʾ����ŵ� Text

    private int _selectedRoom = 1;
    private const int MAX_ROOM = 10;
    private const int MIN_ROOM = 1;

    // ��������
    private bool _aWasPressed = false;
    private bool _xWasPressed = false;
    private bool _yWasPressed = false;

    private void OnEnable()
    {
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnConnected += ShowConnectedCanvas;
            PicoWebSocketClient.Instance.OnDisconnected += ShowDisconnectedCanvas;

            if (!string.IsNullOrEmpty(PicoWebSocketClient.Instance.PlayerId))
                ShowConnectedCanvas();
            else
                ShowDisconnectedCanvas();
        }
        else
        {
            ShowDisconnectedCanvas();
        }

        UpdateRoomText();
    }

    private void OnDisable()
    {
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnConnected -= ShowConnectedCanvas;
            PicoWebSocketClient.Instance.OnDisconnected -= ShowDisconnectedCanvas;
        }
    }

    private void Update()
    {
        // ֻ�� B Canvas ��ʾʱ��Ӧ����
        if (disconnectedCanvas == null || !disconnectedCanvas.enabled) return;

        // ���� A �� �� ��һ������
        bool aPressed = UnityEngine.XR.InputDevices
            .GetDeviceAtXRNode(UnityEngine.XR.XRNode.RightHand)
            .TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool aVal) && aVal;

        if (aPressed && !_aWasPressed)
        {
            _selectedRoom = (_selectedRoom >= MAX_ROOM) ? MIN_ROOM : _selectedRoom + 1;
            UpdateRoomText();
            //Debug.Log($"[NetworkUIManager] �л������� {_selectedRoom}");
        }
        _aWasPressed = aPressed;

        // ���� X �� �� ��һ������
        bool xPressed = UnityEngine.XR.InputDevices
            .GetDeviceAtXRNode(UnityEngine.XR.XRNode.LeftHand)
            .TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool xVal) && xVal;

        if (xPressed && !_xWasPressed)
        {
            _selectedRoom = (_selectedRoom <= MIN_ROOM) ? MAX_ROOM : _selectedRoom - 1;
            UpdateRoomText();
            //Debug.Log($"[NetworkUIManager] �л������� {_selectedRoom}");
        }
        _xWasPressed = xPressed;

        // ���� Y �� �� ���뷿��
        bool yPressed = UnityEngine.XR.InputDevices
            .GetDeviceAtXRNode(UnityEngine.XR.XRNode.LeftHand)
            .TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool yVal) && yVal;

        if (yPressed && !_yWasPressed)
        {
            //Debug.Log($"[NetworkUIManager] ȷ�Ͻ��뷿�� {_selectedRoom}");
            ConnectToRoom();
        }
        _yWasPressed = yPressed;
    }

    private async void ConnectToRoom()
    {
        if (roomNumberText != null)
            roomNumberText.text = "���ӷ�����...";
        if (PicoWebSocketClient.Instance != null)
            await PicoWebSocketClient.Instance.ConnectToRoom(_selectedRoom);
        //else
            //Debug.LogError("[NetworkUIManager] PicoWebSocketClient.Instance Ϊ�գ�");
    }

    private void UpdateRoomText()
    {
        if (roomNumberText != null)
            roomNumberText.text = $"���� {_selectedRoom}";
    }

    private void ShowConnectedCanvas()
    {
        connectedCanvas.enabled = true;
        disconnectedCanvas.enabled = false;
        //Debug.Log("[NetworkUIManager] ��ʾ������Canvas");
    }

    private void ShowDisconnectedCanvas()
    {
        connectedCanvas.enabled = false;
        disconnectedCanvas.enabled = true;
        //Debug.Log("[NetworkUIManager] ��ʾδ����Canvas");
        FindObjectOfType<SilencePropController>()?.HidePropUI();
    }
}