// PicoRemotePlayerManager.cs
using BubbleBattle.Network;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.XR;
using TMPro;
using System.Collections;

/// <summary>
/// Pico MR�豸ר�õ�Զ����ҹ�����
/// רΪPico�豸�Ż�������XR׷�١������Ż���MR��������
/// </summary>
public class PicoRemotePlayerManager : MonoBehaviour
{
    [SerializeField] private GameObject playerPrefab; // Զ�����ģ��Ԥ����
    [SerializeField] private Transform playersParent; // Զ����Ҷ���ĸ�����

    [Header("Pico MR �ض�����")]
    [SerializeField] private float updateThreshold = 0.01f; // λ�ø�����ֵ���ף�
    [SerializeField] private float rotationThreshold = 0.1f; // ��ת������ֵ
    [SerializeField] private float smoothTime = 0.1f; // ƽ���ƶ�ʱ��
    [SerializeField] private int maxRemotePlayersShown = 10; // �����ʾ��Զ�������
    [SerializeField] private float cullingDistance = 50f; // �Ӿ෶Χ���ף�

    [Header("�����Ż�")]
    [SerializeField] private bool enableLOD = true; // ����LODϵͳ
    [SerializeField] private bool enablePositionSmoothing = true; // ����λ��ƽ��
    [SerializeField] private int updateFrameSkip = 2; // ÿN֡����һ��Զ�����

    private Dictionary<string, RemotePlayer> remotePlayersDict = new();
    private HashSet<string> currentPlayerIds = new();
    private int frameCounter = 0;

    [SerializeField] private GameObject healthBarPrefab;
    [SerializeField] private GameObject playerPrefabRed;   // ������Ԥ����  
    [SerializeField] private GameObject playerPrefabBlue;  // �������Ԥ����  

    // Pico XR׷�����
    private List<XRNodeState> nodeStates = new();
    private Vector3 localPlayerPosition; // ���������������

    //
    [SerializeField] private GameObject invincibleEffectPrefab;  // �޵���ЧԤ����  
    private Dictionary<string, InvincibleStateInfo> invincibleStatesDict = new();
    private Dictionary<string, int> remotePlayerLastBlood = new();

    void Start()
    {
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnWorldStateReceived += HandleWorldState;
            PicoWebSocketClient.Instance.OnPlayersBloodReceived += HandlePlayersBloodUpdate;
            PicoWebSocketClient.Instance.OnInvincibleStateReceived += HandleInvincibleStateUpdate;
        }
        else
        {
            //Debug.LogError("[PicoRemotePlayerManager] PicoWebSocketClient.Instance Ϊ�գ�");
        }
    }

    void Update()
    {
        frameCounter++;
        SyncInvincibleEffectPositions();
        // ��ȡ�������λ�ã������Ӿ��޳���
        UpdateLocalPlayerPosition();
    }
    private void SyncInvincibleEffectPositions()
    {
        foreach (var state in invincibleStatesDict.Values)
        {
            if (state.isInvincible && state.invincibleCountdown > 0
            && remotePlayersDict.TryGetValue(state.playerId, out var remotePlayer))
            {
                Transform invincibleEffect = remotePlayer.GameObject.transform.Find("InvincibleEffect");
                if (invincibleEffect != null && invincibleEffect.gameObject.activeSelf)  //������  
                {
                    invincibleEffect.position = remotePlayer.GameObject.transform.position;
                }
            }
        }
    }


    private void UpdateLocalPlayerPosition()
    {
        // ��Pico XR�豸��ȡͷ��λ��  
        InputTracking.GetNodeStates(nodeStates);

        foreach (var nodeState in nodeStates)
        {
            if (nodeState.nodeType == XRNode.Head && nodeState.tracked)
            {
                nodeState.TryGetPosition(out localPlayerPosition);
                break;
            }
        }
    }

    private void HandleWorldState(WorldStateMsg worldState)
    {
        if (worldState?.teams == null)
            return;

        currentPlayerIds.Clear();
        int displayedPlayers = 0;

        // �������ж�������
        foreach (var team in worldState.teams)
        {
            if (team?.players == null)
                continue;

            foreach (var playerState in team.players)
            {
                // �����������
                if (playerState.playerId == PicoWebSocketClient.Instance?.PlayerId)
                    continue;

                currentPlayerIds.Add(playerState.playerId);

                // Pico�����Ż���������ʾ�������
                if (displayedPlayers >= maxRemotePlayersShown)
                    continue;

                // �Ӿ��޳�
                if (!IsPlayerInViewDistance(playerState))
                    continue;

                UpdateRemotePlayer(playerState, team.teamId);
                displayedPlayers++;
            }
        }

        // �Ƴ������б��е����
        RemoveDisconnectedPlayers();
    }

    /*
    // �޸� IsPlayerInViewDistance �����Դ���ê���������
    private bool IsPlayerInViewDistance(PlayerStateInfo playerState)
    {
        Vector3 playerPosFromMessage = new Vector3(
            playerState.position.x,
            playerState.position.y,
            playerState.position.z
        );

        Vector3 playerWorldPosition;

        // ������ڹ���ê�㣬�����յ��ľֲ�����ת��Ϊ��������
        if (PicoWebSocketClient.Instance.SharedAnchorTransform != null)
        {
            playerWorldPosition = PicoWebSocketClient.Instance.SharedAnchorTransform.TransformPoint(playerPosFromMessage);
        }
        else
        {
            // ���򣬼ٶ����յ��ľ����������꣨����Ϊ����ê�㳡����
            playerWorldPosition = playerPosFromMessage;
        }

        // localPlayerPosition �Ѿ�����������
        float distance = Vector3.Distance(localPlayerPosition, playerWorldPosition);
        return distance <= cullingDistance;
    }*/
    private bool IsPlayerInViewDistance(PlayerStateInfo playerState)
    {
        Vector3 playerWorldPosition = new Vector3(
            playerState.position.x,
            playerState.position.y,
            playerState.position.z
        );

        float distance = Vector3.Distance(localPlayerPosition, playerWorldPosition);
        return distance <= cullingDistance;
    }

    private void UpdateRemotePlayer(PlayerStateInfo playerState, string teamId)
    {
        if (remotePlayersDict.ContainsKey(playerState.playerId))
        {
            var remotePlayer = remotePlayersDict[playerState.playerId];
            UpdateExistingPlayer(remotePlayer, playerState);
        }
        else
        {
            // ����ʱ���� teamId  
            CreateRemotePlayer(playerState, teamId);
        }
    }
    /*
    // �޸� UpdateExistingPlayer �����Դ���ê���������
    private void UpdateExistingPlayer(RemotePlayer remotePlayer, PlayerStateInfo playerState)
    {
        Vector3 newPositionFromMessage = new Vector3(
            playerState.position.x,
            playerState.position.y,
            playerState.position.z
        );

        Quaternion newRotationFromMessage = new Quaternion(
            playerState.rotation.x,
            playerState.rotation.y,
            playerState.rotation.z,
            playerState.rotation.w
        );

        Vector3 targetWorldPosition;
        Quaternion targetWorldRotation;

        // ������ڹ���ê�㣬�����յ��ľֲ�����ת��Ϊ��������
        if (PicoWebSocketClient.Instance.SharedAnchorTransform != null)
        {
            targetWorldPosition = PicoWebSocketClient.Instance.SharedAnchorTransform.TransformPoint(newPositionFromMessage);
            targetWorldRotation = PicoWebSocketClient.Instance.SharedAnchorTransform.rotation * newRotationFromMessage; // ע�������ǳ˷�
        }
        else
        {
            // ���򣬼ٶ����յ��ľ�����������
            targetWorldPosition = newPositionFromMessage;
            targetWorldRotation = newRotationFromMessage;
        }


        // ���λ�ñ仯�Ƿ��㹻�� (��Ŀ������λ�ñȽ�)
        float positionDelta = Vector3.Distance(remotePlayer.CurrentPosition, targetWorldPosition);
        float rotationDelta = Quaternion.Angle(remotePlayer.CurrentRotation, targetWorldRotation);

        if (positionDelta > updateThreshold || rotationDelta > rotationThreshold)
        {
            remotePlayer.TargetPosition = targetWorldPosition;
            remotePlayer.TargetRotation = targetWorldRotation;
            remotePlayer.LastUpdateTime = Time.time;

            // Pico�����Ż���Զ�������֡����
            if (enableLOD && frameCounter % updateFrameSkip == 0)
            {
                // Զ�����ʹ�ø���Ƶ��
                int distance = (int)Vector3.Distance(localPlayerPosition, targetWorldPosition); // ��Ŀ������λ�ñȽ�
                if (distance > cullingDistance * 0.5f)
                    return;
            }

            // �������»�ƽ������
            if (enablePositionSmoothing)
            {
                remotePlayer.IsSmoothing = true;
            }
            else
            {
                remotePlayer.GameObject.transform.position = targetWorldPosition;
                remotePlayer.GameObject.transform.rotation = targetWorldRotation;
                remotePlayer.CurrentPosition = targetWorldPosition;
                remotePlayer.CurrentRotation = targetWorldRotation;
            }
        }

        // Ӧ��ƽ���ƶ�
        if (remotePlayer.IsSmoothing)
        {
            remotePlayer.GameObject.transform.position = Vector3.Lerp(
                remotePlayer.GameObject.transform.position,
                remotePlayer.TargetPosition,
                Time.deltaTime / smoothTime
            );

            remotePlayer.GameObject.transform.rotation = Quaternion.Lerp(
                remotePlayer.GameObject.transform.rotation,
                remotePlayer.TargetRotation,
                Time.deltaTime / smoothTime
            );

            // ����Ƿ�ӽ�Ŀ��
            if (Vector3.Distance(remotePlayer.GameObject.transform.position, remotePlayer.TargetPosition) < 0.001f)
            {
                remotePlayer.IsSmoothing = false;
                remotePlayer.CurrentPosition = remotePlayer.TargetPosition;
                remotePlayer.CurrentRotation = remotePlayer.TargetRotation;
            }
        }
    }*/
    private void UpdateExistingPlayer(RemotePlayer remotePlayer, PlayerStateInfo playerState)
    {
        Vector3 targetWorldPosition = new Vector3(
            playerState.position.x,
            playerState.position.y,
            playerState.position.z
        );

        Quaternion targetWorldRotation = new Quaternion(
            playerState.rotation.x,
            playerState.rotation.y,
            playerState.rotation.z,
            playerState.rotation.w
        );

        // ���λ�ñ仯�Ƿ��㹻��  
        float positionDelta = Vector3.Distance(remotePlayer.CurrentPosition, targetWorldPosition);
        float rotationDelta = Quaternion.Angle(remotePlayer.CurrentRotation, targetWorldRotation);

        if (positionDelta > updateThreshold || rotationDelta > rotationThreshold)
        {
            remotePlayer.TargetPosition = targetWorldPosition;
            remotePlayer.TargetRotation = targetWorldRotation;
            remotePlayer.LastUpdateTime = Time.time;

            if (enableLOD && frameCounter % updateFrameSkip == 0)
            {
                int distance = (int)Vector3.Distance(localPlayerPosition, targetWorldPosition);
                if (distance > cullingDistance * 0.5f)
                    return;
            }

            if (enablePositionSmoothing)
            {
                remotePlayer.IsSmoothing = true;
            }
            else
            {
                remotePlayer.GameObject.transform.position = targetWorldPosition;
                remotePlayer.GameObject.transform.rotation = targetWorldRotation;
                remotePlayer.CurrentPosition = targetWorldPosition;
                remotePlayer.CurrentRotation = targetWorldRotation;
            }
        }

        // ƽ���ƶ��߼����ֲ���...  
        // Ӧ��ƽ���ƶ�
        if (remotePlayer.IsSmoothing)
        {
            remotePlayer.GameObject.transform.position = Vector3.Lerp(
                remotePlayer.GameObject.transform.position,
                remotePlayer.TargetPosition,
                Time.deltaTime / smoothTime
            );

            remotePlayer.GameObject.transform.rotation = Quaternion.Lerp(
                remotePlayer.GameObject.transform.rotation,
                remotePlayer.TargetRotation,
                Time.deltaTime / smoothTime
            );

            // ����Ƿ�ӽ�Ŀ��
            if (Vector3.Distance(remotePlayer.GameObject.transform.position, remotePlayer.TargetPosition) < 0.001f)
            {
                remotePlayer.IsSmoothing = false;
                remotePlayer.CurrentPosition = remotePlayer.TargetPosition;
                remotePlayer.CurrentRotation = remotePlayer.TargetRotation;
            }
        }
    }
    /// <summary>  
    /// ���ݶ���ID��ȡ��Ӧ�����Ԥ����  
    /// </summary>  
    private GameObject GetPlayerPrefabByTeam(string teamId)
    {
        if (string.IsNullOrEmpty(teamId))
        {
            //Debug.LogWarning("[PicoRemotePlayerManager] TeamId Ϊ�գ�ʹ��Ĭ��Ԥ����");
            return playerPrefab;
        }

        if (teamId.ToLower().Contains("red"))
        {
            if (playerPrefabRed == null)
            {
                //Debug.LogError("[PicoRemotePlayerManager] playerPrefabRed δ��ֵ��");
                return playerPrefab; // ���˵�Ĭ��Ԥ����  
            }
            return playerPrefabRed;
        }
        else if (teamId.ToLower().Contains("blue"))
        {
            if (playerPrefabBlue == null)
            {
                //Debug.LogError("[PicoRemotePlayerManager] playerPrefabBlue δ��ֵ��");
                return playerPrefab; // ���˵�Ĭ��Ԥ����  
            }
            return playerPrefabBlue;
        }

        //Debug.LogWarning($"[PicoRemotePlayerManager] �޷�ʶ�� TeamId: {teamId}��ʹ��Ĭ��Ԥ����");
        return playerPrefab;
    }

    private void CreateRemotePlayer(PlayerStateInfo playerState, string teamId)
    {
        /*
        if (playerPrefab == null)
        {
            Debug.LogError("[PicoRemotePlayerManager] playerPrefab δָ����");
            return;
        }

        Vector3 finalSpawnPosition = new Vector3(
            playerState.position.x,
            playerState.position.y,
            playerState.position.z
        );

        Quaternion finalSpawnRotation = new Quaternion(
            playerState.rotation.x,
            playerState.rotation.y,
            playerState.rotation.z,
            playerState.rotation.w
        );

        // ʵ������Ҷ���  
        GameObject playerObj = Instantiate(
            playerPrefab,
            */
            // ���� teamId ��ȡ��Ӧ��Ԥ����
            GameObject selectedPrefab = GetPlayerPrefabByTeam(teamId);

            if (selectedPrefab == null)
            {
                //Debug.LogError("[PicoRemotePlayerManager] �޷���ȡ��Ч�����Ԥ���壡");
                return;
            }

            Vector3 finalSpawnPosition = new Vector3(
                playerState.position.x,
                playerState.position.y,
                playerState.position.z
            );

            Quaternion finalSpawnRotation = new Quaternion(
                playerState.rotation.x,
                playerState.rotation.y,
                playerState.rotation.z,
                playerState.rotation.w
            );

            // ʵ������Ҷ���  
            GameObject playerObj = Instantiate(
                selectedPrefab,  // �� ʹ��ѡ�е�Ԥ����
                finalSpawnPosition,
                finalSpawnRotation,
            playersParent
        );

        playerObj.name = $"RemotePlayer_{playerState.playerName}";
        playerObj.tag = "RemotePlayer";

        // ����������ײ  
        Collider[] colliders = playerObj.GetComponentsInChildren<Collider>();
        foreach (var collider in colliders)
        {
            collider.enabled = false;
        }

        // ��ʾ������ֺ�Ѫ��...  
        SetPlayerNameDisplay(playerObj, playerState.playerName);
        CreateRemotePlayerHealthBar(playerObj, playerState.playerId, playerState.playerName, teamId);

        // ����RemotePlayer���ݽṹ  
        var remotePlayer = new RemotePlayer
        {
            PlayerId = playerState.playerId,
            PlayerName = playerState.playerName,
            GameObject = playerObj,
            CurrentPosition = finalSpawnPosition,
            CurrentRotation = finalSpawnRotation,
            TargetPosition = finalSpawnPosition,
            TargetRotation = finalSpawnRotation,
            LastUpdateTime = Time.time,
            IsSmoothing = false,
            TeamId = teamId
        };

        remotePlayersDict[playerState.playerId] = remotePlayer;
        //Debug.Log($"[PicoRemotePlayerManager] ����Զ�����: {playerState.playerName} ({playerState.playerId}) ��λ��: {finalSpawnPosition}");
    }

    private void SetPlayerNameDisplay(GameObject playerObj, string playerName)
    {
        // ����TextMesh�������������
        TextMesh textMesh = playerObj.GetComponentInChildren<TextMesh>();
        if (textMesh != null)
        {
            textMesh.text = playerName;
            textMesh.fontSize = 100;
            textMesh.anchor = TextAnchor.MiddleCenter;
        }

        // ���߲���TextMeshPro
        var textMeshPro = playerObj.GetComponentInChildren<TMPro.TextMeshPro>();
        if (textMeshPro != null)
        {
            textMeshPro.text = playerName;
            textMeshPro.alignment = TMPro.TextAlignmentOptions.Center;
        }
    }

    /// <summary>  
    /// ����Ѫ�����¹㲥  
    /// </summary>  
    private void HandlePlayersBloodUpdate(PlayersBloodMsg bloodMsg)
    {
        //Debug.Log("����HandlePlayersBloodUpdate");
        if (bloodMsg?.teams == null || bloodMsg.teams.Length == 0)
        {
            //Debug.LogWarning("[PicoRemotePlayerManager] �յ���Ѫ����ϢΪ��");
            return;
        }

        // �������ж�������  
        foreach (var teamInfo in bloodMsg.teams)
        {

            if (teamInfo?.players == null)
                continue;
            //Debug.Log("����foreach");
            foreach (var playerBlood in teamInfo.players)
            {
                // �����������  
                if (playerBlood.playerId == PicoWebSocketClient.Instance?.PlayerId)
                    continue;
                //Debug.Log("�����������");
                // ����Զ�����Ѫ��  
                if (remotePlayersDict.TryGetValue(playerBlood.playerId, out var remotePlayer))
                {
                    // ͬ��Ѫ������λ�ã��ؼ�����  
                    Transform healthBar = remotePlayer.GameObject.transform.Find("HealthBar");
                    if (healthBar != null)
                    {
                        healthBar.position = remotePlayer.GameObject.transform.position + Vector3.up * 0.3f;
                    }

                    var healthBarScript = remotePlayer.GameObject.GetComponentInChildren<RemotePlayerHealthBar>();
                    if (healthBarScript != null)
                    {
                        healthBarScript.UpdateHealth(playerBlood.blood, playerBlood.maxBlood);
                    }

                    if (remotePlayerLastBlood.TryGetValue(playerBlood.playerId, out int lastBlood))
                    {
                        if (playerBlood.blood > lastBlood)
                            ShowBloodVFX(remotePlayer.GameObject, "HealEffect");
                        else if (playerBlood.blood < lastBlood)
                            ShowBloodVFX(remotePlayer.GameObject, "DamageEffect");
                    }
                    // ��¼����Ѫ�������´αȽ�  
                    remotePlayerLastBlood[playerBlood.playerId] = playerBlood.blood;

                }
            }
        }
    }

    void OnDestroy()
    {
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnWorldStateReceived -= HandleWorldState;
            //ע��Ѫ���¼�����  
            PicoWebSocketClient.Instance.OnPlayersBloodReceived -= HandlePlayersBloodUpdate;
            PicoWebSocketClient.Instance.OnInvincibleStateReceived -= HandleInvincibleStateUpdate;
        }
    }

    /// <summary>  
    /// ΪԶ����Ҵ���Ѫ����ʾ  
    /// Ѫ��Ԥ������� white/red/blue ����������RemotePlayerHealthBar ���� teamId �����Ӧ����  
    /// </summary>  
    private void CreateRemotePlayerHealthBar(GameObject playerObj, string playerId, string playerName, string teamId)
    {
        if (healthBarPrefab == null)
        {
            //Debug.LogError("[PicoRemotePlayerManager] healthBarPrefab δָ����");
            return;
        }

        // ʵ����Ѫ��Ԥ���壨�����ͷ����  
        GameObject healthBarContainer = Instantiate(
            healthBarPrefab,
            playerObj.transform.position,
            Quaternion.identity,
            playerObj.transform
        );
        Canvas canvas = healthBarContainer.GetComponent<Canvas>();

        // ǿ�Ƹĳ� World Space
        canvas.renderMode = RenderMode.WorldSpace;

        healthBarContainer.name = "HealthBar";
        healthBarContainer.transform.localPosition = new Vector3(0, 0.3f, 0);

        // ����Ѫ�����Ŵ�С  
        healthBarContainer.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);

        // ���� BillboardUI�����Ԥ������û�У�  
        if (healthBarContainer.GetComponent<BillboardUI>() == null)
        {
            healthBarContainer.AddComponent<BillboardUI>();
        }

        // ��ȡ������ RemotePlayerHealthBar �ű�  
        RemotePlayerHealthBar healthBar = healthBarContainer.GetComponent<RemotePlayerHealthBar>();
        if (healthBar == null)
        {
            healthBar = healthBarContainer.AddComponent<RemotePlayerHealthBar>();
        }

        // ��ʼ��Ѫ�������� teamId  
        // RemotePlayerHealthBar ����� teamId �����Ӧ�� red/blue ������white ʼ����ʾ  
        healthBar.Initialize(playerId, 6, teamId);

        //Debug.Log($"[PicoRemotePlayerManager] Ϊ��� {playerName}({playerId}) ������Ѫ��UI������: {teamId}");
    }
    /*
    // ���������ݶ���ѡ��Ѫ��Ԥ����  
    private GameObject GetHealthBarPrefabByTeam(string teamId)
    {
        if (string.IsNullOrEmpty(teamId))
        {
            Debug.LogWarning("[PicoRemotePlayerManager] TeamId Ϊ�գ�ʹ��Ĭ�Ϻ��Ѫ��");
            return healthBarPrefabRed;
        }

        if (teamId.ToLower().Contains("red"))
        {
            if (healthBarPrefabRed == null)
                Debug.LogError("[PicoRemotePlayerManager] healthBarPrefabRed δ��ֵ��");
            return healthBarPrefabRed;
        }
        else if (teamId.ToLower().Contains("blue"))
        {
            if (healthBarPrefabBlue == null)
                Debug.LogError("[PicoRemotePlayerManager] healthBarPrefabBlue δ��ֵ��");
            return healthBarPrefabBlue;
        }

        Debug.LogError($"[PicoRemotePlayerManager] �޷�ʶ�� TeamId: {teamId}");
        return null;
    }*/

    private void RemoveDisconnectedPlayers()
    {
        var playerIdsToRemove = new List<string>();

        foreach (var playerId in remotePlayersDict.Keys)
        {
            if (!currentPlayerIds.Contains(playerId))
            {
                playerIdsToRemove.Add(playerId);
            }
        }

        foreach (var playerId in playerIdsToRemove)
        {
            if (remotePlayersDict.TryGetValue(playerId, out var remotePlayer))
            {
                //Debug.Log($"[PicoRemotePlayerManager] �Ƴ�Զ�����: {remotePlayer.PlayerName}");
                Destroy(remotePlayer.GameObject);
                remotePlayerLastBlood.Remove(playerId);
                remotePlayersDict.Remove(playerId);
            }
        }
    }

    /// <summary>
    /// Զ��������ݽṹ
    /// </summary>
    public class RemotePlayer
    {
        public string PlayerId { get; set; }
        public string PlayerName { get; set; }
        public GameObject GameObject { get; set; }
        public Vector3 CurrentPosition { get; set; } // �洢��������
        public Quaternion CurrentRotation { get; set; } // �洢������ת
        public Vector3 TargetPosition { get; set; } // �洢��������
        public Quaternion TargetRotation { get; set; } // �洢������ת
        public float LastUpdateTime { get; set; }
        public bool IsSmoothing { get; set; }
        public string TeamId { get; set; }
    }

    // ���Է���
    public void SetCullingDistance(float distance)
    {
        cullingDistance = distance;
        //Debug.Log($"[PicoRemotePlayerManager] �Ӿ�����Ϊ: {distance}��");
    }

    public int GetActiveRemotePlayerCount()
    {
        return remotePlayersDict.Count;
    }

    public void ToggleLOD(bool enable)
    {
        enableLOD = enable;
        //Debug.Log($"[PicoRemotePlayerManager] LODϵͳ: {(enable ? "����" : "����")}");
    }

    /// <summary>  
    /// ��ȡ����Զ������ֵ䣬�� PlayerResultEffectManager ʹ��  
    /// </summary>  
    public Dictionary<string, RemotePlayer> GetAllRemotePlayers()
    {
        return remotePlayersDict;
    }

    //�޵���Ч
    private void HandleInvincibleStateUpdate(InvincibleStateMessage invincibleMsg)
    {
        if (invincibleMsg?.invincibleStates == null || invincibleMsg.invincibleStates.Length == 0)
        {
            return;
        }

        // �����޵�״̬�ֵ�  
        foreach (var state in invincibleMsg.invincibleStates)
        {
            invincibleStatesDict[state.playerId] = state;

            // ��ȡ��Ӧ��Զ����ң���ʾ/�����޵���Ч  
            if (remotePlayersDict.TryGetValue(state.playerId, out var remotePlayer))
            {
                UpdateInvincibleEffect(remotePlayer, state);
            }
        }

        //Debug.Log($"[PicoRemotePlayerManager] �����޵�״̬: {invincibleMsg.invincibleStates.Length} �����");
    }

    private void UpdateInvincibleEffect(RemotePlayer remotePlayer, InvincibleStateInfo state)
    {
        Transform invincibleEffect = remotePlayer.GameObject.transform.Find("InvincibleEffect");

        // ��ʾ��������Ч�������޵�״̬��  
        if (state.isInvincible && state.invincibleCountdown > 0)
        {
            if (invincibleEffect == null)
            {
                if (invincibleEffectPrefab != null)
                {
                    invincibleEffect = Instantiate(
                        invincibleEffectPrefab,
                        remotePlayer.GameObject.transform.position,
                        Quaternion.identity,
                        remotePlayer.GameObject.transform
                    ).transform;
                    invincibleEffect.name = "InvincibleEffect";
                    invincibleEffect.localPosition = Vector3.zero;
                }
            }
            else if (!invincibleEffect.gameObject.activeSelf)
            {
                invincibleEffect.gameObject.SetActive(true);
            }

            // ���ݵ���ʱ������˸Ч��  
            UpdateInvincibleEffectAnimation(invincibleEffect, state.invincibleCountdown);
        }
        else
        {
            // �޵н�����������Ч  
            if (invincibleEffect != null && invincibleEffect.gameObject.activeSelf)
            {
                invincibleEffect.gameObject.SetActive(false);
            }
        }
    }

    private void UpdateInvincibleEffectAnimation(Transform effect, float countdown)
    {
        // ����ʱ���2����˸  
        if (countdown <= 2f)
        {
            if (effect.TryGetComponent<CanvasGroup>(out var canvasGroup))
            {
                float alpha = Mathf.Abs(Mathf.Sin(Time.time * 5f));
                canvasGroup.alpha = alpha;
            }

            if (effect.TryGetComponent<Renderer>(out var renderer))
            {
                float alpha = Mathf.Abs(Mathf.Sin(Time.time * 5f));
                Color color = renderer.material.color;
                color.a = alpha;
                renderer.material.color = color;
            }
        }
    }

    private void ShowBloodVFX(GameObject playerObj, string effectName)
    {
        Transform vfx = playerObj.transform.Find(effectName);
        if (vfx == null) return;

        StartCoroutine(AutoPlayVFX(vfx.gameObject));
    }

    private IEnumerator AutoPlayVFX(GameObject vfx)
    {
        vfx.SetActive(true);

        var ps = vfx.GetComponentInChildren<ParticleSystem>();
        if (ps != null)
        {
            ps.Stop();
            ps.Play();
            yield return new WaitForSeconds(ps.main.duration + ps.main.startLifetime.constantMax);
        }
        else
        {
            yield return new WaitForSeconds(1.5f);
        }

        vfx.SetActive(false);
    }
}
