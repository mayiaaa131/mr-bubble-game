using BubbleBattle.Network;
using UnityEngine;
using System.Collections.Generic;

public class RemotePlayerManager : MonoBehaviour
{
    [SerializeField] private GameObject playerPrefab; // ���ģ��Ԥ����
    [SerializeField] private Transform playersParent; // ����Զ����ҵĸ����󣨿�ѡ��

    private Dictionary<string, GameObject> remotePlayersDict = new();
    private HashSet<string> currentPlayerIds = new();

    void Start()
    {
        // �����¼�
        WebSocketClient.Instance.OnWorldStateReceived += HandleWorldState;
    }

    private void HandleWorldState(WorldStateMsg worldState)
    {
        currentPlayerIds.Clear();

        // �������ж�������
        foreach (var team in worldState.teams)
        {
            foreach (var playerState in team.players)
            {
                // �����������
                if (playerState.playerId == WebSocketClient.Instance.PlayerId)
                    continue;

                currentPlayerIds.Add(playerState.playerId);

                // ��ʾ������������
                UpdateRemotePlayer(playerState);
            }
        }

        // �Ƴ������б��е���ң�����뿪�ˣ�
        RemoveDisconnectedPlayers();
    }

    private void UpdateRemotePlayer(PlayerStateInfo playerState)
    {
        if (remotePlayersDict.ContainsKey(playerState.playerId))
        {
            // �����������λ�ú���ת
            var playerObj = remotePlayersDict[playerState.playerId];
            playerObj.transform.position = new Vector3(
                playerState.position.x,
                playerState.position.y,
                playerState.position.z
            );
            playerObj.transform.rotation = new Quaternion(
                playerState.rotation.x,
                playerState.rotation.y,
                playerState.rotation.z,
                playerState.rotation.w
            );
        }
        else
        {
            // ��������Ҷ���
            CreateRemotePlayer(playerState);
        }
    }

    private void CreateRemotePlayer(PlayerStateInfo playerState)
    {
        if (playerPrefab == null)
        {
            Debug.LogError("[RemotePlayerManager] playerPrefab δָ����");
            return;
        }

        // ʵ������Ҷ���
        GameObject newPlayerObj = Instantiate(
            playerPrefab,
            new Vector3(playerState.position.x, playerState.position.y, playerState.position.z),
            new Quaternion(playerState.rotation.x, playerState.rotation.y, playerState.rotation.z, playerState.rotation.w),
            playersParent
        );

        newPlayerObj.name = playerState.playerName;

        // ���ӱ�ǩ������Ա�ʶ����Զ�����
        newPlayerObj.tag = "RemotePlayer";

        // �����TextMesh����ʾ�������
        var textMesh = newPlayerObj.GetComponentInChildren<TextMesh>();
        if (textMesh != null)
        {
            textMesh.text = playerState.playerName;
        }

        // ���浽�ֵ�
        remotePlayersDict[playerState.playerId] = newPlayerObj;

        Debug.Log($"[RemotePlayerManager] ����Զ�����: {playerState.playerName} ({playerState.playerId})");
    }

    private void RemoveDisconnectedPlayers()
    {
        var playerIdsToRemove = new List<string>();

        // �ҳ���Ҫ�Ƴ������
        foreach (var playerId in remotePlayersDict.Keys)
        {
            if (!currentPlayerIds.Contains(playerId))
            {
                playerIdsToRemove.Add(playerId);
            }
        }

        // �Ƴ���Ҷ���
        foreach (var playerId in playerIdsToRemove)
        {
            if (remotePlayersDict.TryGetValue(playerId, out var playerObj))
            {
                Debug.Log($"[RemotePlayerManager] �Ƴ�Զ�����: {playerId}");
                Destroy(playerObj);
                remotePlayersDict.Remove(playerId);
            }
        }
    }

    void OnDestroy()
    {
        if (WebSocketClient.Instance != null)
        {
            WebSocketClient.Instance.OnWorldStateReceived -= HandleWorldState;
        }
    }
}
