using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System;
using System.Threading.Tasks;
using Unity.XR.PXR;
using UnityEngine.XR;

/// <summary>
/// ƽ���������
/// ��������/ֹͣƽ���⣬��ά��ƽ�����ݻ���
/// </summary>
public class PlaneDetectionManager : MonoBehaviour
{
    public static PlaneDetectionManager Instance { get; private set; }

    private Dictionary<Guid, PxrPlaneData> _detectedPlanes = new Dictionary<Guid, PxrPlaneData>();
    private List<PxrPlaneData> _floorPlanes = new List<PxrPlaneData>();

    public event Action<List<PxrPlaneData>> OnPlanesUpdated;
    public bool IsReady { get; private set; } = false;

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        _ = StartPlaneDetectionAsync();
    }

    private async Task StartPlaneDetectionAsync()
    {
        Debug.Log("[PlaneDetection] ��������ƽ����...");

        PxrResult startResult = await PXR_MixedReality.StartSenseDataProvider(
            PxrSenseDataProviderType.PlaneDetection
        );

        Debug.Log($"[PlaneDetection] StartSenseDataProvider ����: {startResult}");

        if (startResult != PxrResult.SUCCESS)
        {
            Debug.LogError($"[PlaneDetection] ����ʧ��: {startResult}\n" +
                           "���飺\n" +
                           "1. AndroidManifest.xml �Ƿ��� com.picovr.permission.SCENE_UNDERSTANDING\n" +
                           "2. PICO ϵͳ�������Ƿ����˿ռ��֪��Ȩ");
            return;
        }

        // ��ѯ�ȴ�״̬��Ϊ Running������ 5 �룩
        int maxWaitMs = 5000;
        int waited = 0;
        int intervalMs = 100;

        while (waited < maxWaitMs)
        {
            PXR_MixedReality.GetSenseDataProviderState(
                PxrSenseDataProviderType.PlaneDetection, out var state);

            Debug.Log($"[PlaneDetection] ��ǰ״̬: {state}���ѵȴ� {waited}ms��");

            if (state == PxrSenseDataProviderState.Running)
            {
                IsReady = true;
                Debug.Log("[PlaneDetection] ƽ�����Ѿ�������ʼ��������");
                return;
            }

            await Task.Delay(intervalMs);
            waited += intervalMs;
        }

        Debug.LogError("[PlaneDetection] ƽ����������ʱ������Ȩ�޺��豸֧��");
    }

    void OnEnable()
    {
        PXR_Manager.PlaneDetectionDataUpdated += HandlePlaneDetectionDataUpdated;
    }

    void OnDisable()
    {
        PXR_Manager.PlaneDetectionDataUpdated -= HandlePlaneDetectionDataUpdated;
    }

    private void HandlePlaneDetectionDataUpdated(List<PxrPlaneData> planeDatas)
    {
        if (planeDatas == null || planeDatas.Count == 0)
            return;

        foreach (PxrPlaneData planeData in planeDatas)
        {
            if (planeData.state == MeshChangeState.Removed)
            {
                _detectedPlanes.Remove(planeData.uuid);
                _floorPlanes.RemoveAll(p => p.uuid == planeData.uuid);
            }
            else
            {
                _detectedPlanes[planeData.uuid] = planeData;

                bool isFloor = planeData.label == PxrSemanticLabel.Floor ||
                               planeData.orientationMode == PxrPlaneOrientation.HorizontalUpward;

                if (isFloor)
                {
                    int existingIdx = _floorPlanes.FindIndex(p => p.uuid == planeData.uuid);
                    if (existingIdx >= 0)
                        _floorPlanes[existingIdx] = planeData;
                    else
                        _floorPlanes.Add(planeData);
                }
            }
        }

        Debug.Log($"[PlaneDetection] ��⵽ {_detectedPlanes.Count} ��ƽ�棬���� {_floorPlanes.Count} ������");
        OnPlanesUpdated?.Invoke(planeDatas);
    }

    public List<PxrPlaneData> GetFloorPlanes() => new List<PxrPlaneData>(_floorPlanes);

    public Dictionary<Guid, PxrPlaneData> GetAllPlanes() => new Dictionary<Guid, PxrPlaneData>(_detectedPlanes);

    public bool HasFloorPlane() => _floorPlanes.Count > 0;

    void OnDestroy()
    {
        Debug.Log("[PlaneDetection] ֹͣƽ���⹦��");
        _ = PXR_MixedReality.StopSenseDataProvider(PxrSenseDataProviderType.PlaneDetection);
    }
}