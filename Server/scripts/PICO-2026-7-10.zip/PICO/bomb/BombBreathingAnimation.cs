using UnityEngine;

public class BombBreathingAnimation : MonoBehaviour
{
    [Header("������������")]
    [SerializeField] private float breathAmplitude = 0.08f;
    [SerializeField] private float breathSpeed = 1.2f;
    [SerializeField] private float speedSmoothTime = 0.5f;

    [Header("�ų����ŵ������壨�絹��ʱCanvas��")]
    [SerializeField] private Transform[ ] excludedChildren;

    private Vector3 _originalScale;
    private bool _isAnimating = true;

    private float _currentSpeed;
    private float _targetSpeed;
    private float _speedVelocity = 0f;
    private float _phase = 0f;

    private Vector3[ ] _excludedOriginalScales;

    void Start( )
    {
        _originalScale = transform.localScale;
        _currentSpeed = breathSpeed;
        _targetSpeed = breathSpeed;

        CacheExcludedScales();
    }

    void Update( )
    {
        if (!_isAnimating) return;

        _currentSpeed = Mathf.SmoothDamp(
            _currentSpeed,
            _targetSpeed,
            ref _speedVelocity,
            speedSmoothTime
        );

        _phase += _currentSpeed * Time.deltaTime;
        if (_phase > 1f) _phase -= 1f;

        float pingPong = Mathf.PingPong(_phase * 2f, 1f);
        float smoothValue = Mathf.SmoothStep(0f, 1f, pingPong);
        float scaleFactor = 1f + (smoothValue * 2f - 1f) * breathAmplitude;

        transform.localScale = _originalScale * scaleFactor;

        // ���򲹳���Canvas ����������
        if (excludedChildren != null)
        {
            for (int i = 0; i < excludedChildren.Length; i++)
            {
                if (excludedChildren[ i ] != null && scaleFactor != 0f)
                {
                    excludedChildren[ i ].localScale = _excludedOriginalScales[ i ] / scaleFactor;
                }
            }
        }
    }

    public void SetBreathSpeed( float speed )
    {
        _targetSpeed = speed;
    }

    /// <summary>
    /// �� �������ⲿ���»�׼���ţ�ը������ʱ���ã�
    /// ƽ�����ɵ��µĻ�׼��С�������������
    /// </summary>
    public void SetBaseScale( Vector3 newBaseScale )
    {
        _originalScale = newBaseScale;
    }

    public void SetExcludedChildren( Transform[ ] children )
    {
        excludedChildren = children;
        CacheExcludedScales();
    }

    public void StopAnimation( )
    {
        _isAnimating = false;
        transform.localScale = _originalScale;

        if (excludedChildren != null)
        {
            for (int i = 0; i < excludedChildren.Length; i++)
            {
                if (excludedChildren[ i ] != null)
                    excludedChildren[ i ].localScale = _excludedOriginalScales[ i ];
            }
        }
    }

    private void CacheExcludedScales( )
    {
        if (excludedChildren == null) return;
        _excludedOriginalScales = new Vector3[ excludedChildren.Length ];
        for (int i = 0; i < excludedChildren.Length; i++)
        {
            if (excludedChildren[ i ] != null)
                _excludedOriginalScales[ i ] = excludedChildren[ i ].localScale;
        }
    }
}
