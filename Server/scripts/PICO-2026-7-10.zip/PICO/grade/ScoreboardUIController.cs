using UnityEngine;
using TMPro;
using BubbleBattle.Network;

/// <summary>
/// �÷���ʾUI���ƽű�
/// ����ʾ��ӵ÷� vs ���ӵ÷֣������������������
/// ʹ�� TextMeshPro
/// </summary>
public class ScoreboardUIController : MonoBehaviour
{
    [Header("����÷���ʾ")]
    [SerializeField] private TextMeshProUGUI redTeamScoreText;
    [SerializeField] private TextMeshProUGUI blueTeamScoreText;

    private int currentRedScore = 0;
    private int currentBlueScore = 0;

    void Start()
    {
        // ���ĵ÷ֹ㲥�¼�
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnScoreBroadcastReceived += OnScoreBroadcastReceived;
        }

        Debug.Log("[ScoreDisplay] ��ʼ�����");
    }

    /// <summary>
    /// ���յ��÷ֹ㲥ʱ����
    /// </summary>
    private void OnScoreBroadcastReceived(ScoreBroadcast scoreBroadcast)
    {
        if (scoreBroadcast?.teams == null || scoreBroadcast.teams.Length == 0)
        {
            Debug.LogWarning("[ScoreDisplay] �յ��ĵ÷���ϢΪ��");
            return;
        }

        // ����������Ϣ
        foreach (var teamInfo in scoreBroadcast.teams)
        {
            if (teamInfo.teamId.ToLower().Contains("red"))
            {
                currentRedScore = teamInfo.totalScore;  // ֱ��ȡ score �ֶ�
                if (redTeamScoreText != null)
                {
                    redTeamScoreText.text = currentRedScore.ToString();
                    Debug.Log($"[ScoreDisplay] ��ӵ÷�: {currentRedScore}");
                }
            }
            else if (teamInfo.teamId.ToLower().Contains("blue"))
            {
                currentBlueScore = teamInfo.totalScore;  // ֱ��ȡ score �ֶ�
                if (blueTeamScoreText != null)
                {
                    blueTeamScoreText.text = currentBlueScore.ToString();
                    Debug.Log($"[ScoreDisplay] ���ӵ÷�: {currentBlueScore}");
                }
            }
        }

        Debug.Log($"[ScoreDisplay] �÷ָ��� - ���: {currentRedScore}, ����: {currentBlueScore}");
    }

    /// <summary>
    /// ��ȡ��ǰ��ӵ÷�
    /// </summary>
    public int GetRedTeamScore() => currentRedScore;

    /// <summary>
    /// ��ȡ��ǰ���ӵ÷�
    /// </summary>
    public int GetBlueTeamScore() => currentBlueScore;

    void OnDestroy()
    {
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnScoreBroadcastReceived -= OnScoreBroadcastReceived;
        }
    }
}
