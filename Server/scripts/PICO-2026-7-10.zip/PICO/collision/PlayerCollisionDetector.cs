using BubbleBattle.Network;
using UnityEngine;

public class PlayerCollisionDetector : MonoBehaviour
{
    [Header("��ȴ����")]
    [SerializeField] private float collisionCooldown = 2f;  // 2����ȴ

    private float _lastCollisionTime = -999f;
    private string _playerId;
    private string _teamId;
    private string _roomId;

    void Start()
    {
        // �� WebSocket �ͻ��˻�ȡ�����Ϣ
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnPlayerAssignedId += (id) =>
            {
                _playerId = id;
                _teamId = PicoWebSocketClient.Instance.TeamId;
                _roomId = PicoWebSocketClient.Instance.RoomId;
                Debug.Log($"[CollisionDetector] ��ҳ�ʼ��: {_playerId}");
            };
        }
    }
    /*
    /// <summary>
    /// OnTriggerEnter - ��⵽��ǽ
    /// </summary>
    private void OnTriggerEnter(Collider other)
    {
        // �����ײ�����Ƿ��� Default Layer
        if (other.gameObject.layer != LayerMask.NameToLayer("Default"))
            return;
        // �����ȴʱ��
        if (Time.time - _lastCollisionTime < collisionCooldown)
            return;
        // ��������Ϣ
        if (string.IsNullOrEmpty(_playerId))
        {
            Debug.LogWarning("[CollisionDetector] ���IDδ��ʼ��");
            return;
        }
        // ������ȴʱ��
        _lastCollisionTime = Time.time;
        // ���ʹ�ǽ��ײ��Ϣ
        SendCollisionMessage();
    }*/
    private void OnTriggerStay(Collider other)
    {
        Debug.Log($"[Collision] Stay with: {other.gameObject.name}");
        if (other.gameObject.layer != LayerMask.NameToLayer("Default"))
            return;
        if (Time.time - _lastCollisionTime < collisionCooldown)
            return;

        if (string.IsNullOrEmpty(_playerId))
            return;

        _lastCollisionTime = Time.time;
        SendCollisionMessage();
    }

    /// <summary>
    /// ������ײ��Ϣ��������
    /// </summary>
    private void SendCollisionMessage()
    {
        var msg = new ObstacleCollisionMsg
        {
            playerId = _playerId,
            teamId = _teamId,
            roomId = _roomId,
            timestamp = System.DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        };

        string json = JsonUtility.ToJson(msg);
        PicoWebSocketClient.Instance.SendRawMessage(json);

        Debug.Log($"[CollisionDetector] ��ǽ��������ײ��Ϣ����ȴ {collisionCooldown}��");
    }
}
