using BubbleBattle.Network;
using UnityEngine;

/// <summary>
/// ��������޵�״̬��������ʾ�޵���Ч��
/// ����˷��͵���ʵʱ����ʱ���ͻ���ֻ��Ҫ��ʾ/������Ч
/// </summary>
public class LocalPlayerInvincibleManager : MonoBehaviour
{
    [SerializeField] private GameObject invincibleEffectPrefab;  // �޵���ЧԤ����
    private GameObject invincibleEffect;
    private Transform localPlayerTransform;
    private string localPlayerId;
    private InvincibleStateInfo currentInvincibleState;

    void Start()
    {
        // ��ȡ�������Transform
        if (localPlayerTransform == null)
        {
            AutoBindXRCamera();
        }

        // ����WebSocket�¼�
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnPlayerAssignedId += OnLocalPlayerIdAssigned;
            PicoWebSocketClient.Instance.OnInvincibleStateReceived += HandleInvincibleStateUpdate;
        }
        else
        {
            Debug.LogError("[LocalPlayerInvincibleManager] PicoWebSocketClient.Instance Ϊ�գ�");
        }
    }

    private void AutoBindXRCamera()
    {
        var xrOrigin = FindObjectOfType<Unity.XR.CoreUtils.XROrigin>();
        if (xrOrigin != null && xrOrigin.Camera != null)
        {
            localPlayerTransform = xrOrigin.Camera.transform;
            return;
        }

        if (Camera.main != null)
        {
            localPlayerTransform = Camera.main.transform;
            return;
        }

        Debug.LogError("[LocalPlayerInvincibleManager] δ�ҵ����� Camera��");
    }

    private void OnLocalPlayerIdAssigned(string playerId)
    {
        localPlayerId = playerId;
        Debug.Log($"[LocalPlayerInvincibleManager] �������ID: {localPlayerId}");
    }

    void Update()
    {
        // ֻ��Ҫʵʱ������Чλ�ú�״̬������Ҫ���㵹��ʱ
        if (invincibleEffect != null && invincibleEffect.activeSelf && currentInvincibleState != null)
        {
            invincibleEffect.transform.position = localPlayerTransform.position;
            UpdateInvincibleEffectAnimation(currentInvincibleState.invincibleCountdown);
        }
    }

    private void HandleInvincibleStateUpdate(InvincibleStateMessage invincibleMsg)
    {
        if (invincibleMsg?.invincibleStates == null || invincibleMsg.invincibleStates.Length == 0)
        {
            return;
        }

        // ���ұ�����ҵ��޵�״̬
        foreach (var state in invincibleMsg.invincibleStates)
        {
            if (state.playerId == localPlayerId)
            {
                currentInvincibleState = state;

                // ֱ��ʹ�÷���˷����ĵ���ʱ����
                if (state.isInvincible && state.invincibleCountdown > 0)
                {
                    ShowInvincibleEffect();
                }
                else
                {
                    HideInvincibleEffect();
                }
                break;
            }
        }
    }

    private void ShowInvincibleEffect()
    {
        if (invincibleEffect == null)
        {
            if (invincibleEffectPrefab != null)
            {
                invincibleEffect = Instantiate(
                    invincibleEffectPrefab,
                    localPlayerTransform.position,
                    Quaternion.identity,
                    localPlayerTransform
                );
                invincibleEffect.name = "LocalPlayerInvincibleEffect";
                invincibleEffect.transform.localPosition = Vector3.zero;
            }
            else
            {
                Debug.LogWarning("[LocalPlayerInvincibleManager] invincibleEffectPrefab δָ����");
                return;
            }
        }
        else if (!invincibleEffect.activeSelf)
        {
            invincibleEffect.SetActive(true);
        }
    }

    private void HideInvincibleEffect()
    {
        if (invincibleEffect != null && invincibleEffect.activeSelf)
        {
            invincibleEffect.SetActive(false);
        }
        currentInvincibleState = null;
    }

    private void UpdateInvincibleEffectAnimation(float countdown)
    {
        // ����ʱ���2����˸
        if (countdown <= 2f)
        {
            if (invincibleEffect != null && invincibleEffect.TryGetComponent<CanvasGroup>(out var canvasGroup))
            {
                float alpha = Mathf.Abs(Mathf.Sin(Time.time * 5f));
                canvasGroup.alpha = alpha;
            }

            if (invincibleEffect != null && invincibleEffect.TryGetComponent<Renderer>(out var renderer))
            {
                float alpha = Mathf.Abs(Mathf.Sin(Time.time * 5f));
                Color color = renderer.material.color;
                color.a = alpha;
                renderer.material.color = color;
            }
        }
    }

    void OnDestroy()
    {
        if (PicoWebSocketClient.Instance != null)
        {
            PicoWebSocketClient.Instance.OnPlayerAssignedId -= OnLocalPlayerIdAssigned;
            PicoWebSocketClient.Instance.OnInvincibleStateReceived -= HandleInvincibleStateUpdate;
        }

        if (invincibleEffect != null)
        {
            Destroy(invincibleEffect);
        }
    }
}
